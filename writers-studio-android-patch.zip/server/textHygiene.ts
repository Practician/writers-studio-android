import { restoreYo } from "./yoRestore";

export interface TextHygieneReport {
  removedHiddenCharacters: number;
  normalizedSpaces: number;
  normalizedLineEndings: boolean;
  fixedPunctuationArtifacts: number;
  punctuationNotes: string[];
  restoredYo: number;
  fixedLatinLeaks: number;
  fixedProperNounCase: number;
  fixedGenderAgreement: number;
  removedBurstinessStubs: number;
  removedDuplicateParagraphs: number;
  changed: boolean;
}

export interface TextHygieneResult {
  text: string;
  report: TextHygieneReport;
}

const LATIN_LEAK_MAP: Record<string, string> = {
  brown: "бурого",
  dark: "тёмно",
  light: "светло",
  grey: "серого",
  gray: "серого",
  black: "чёрного",
  green: "зелёного",
  red: "красного",
  blue: "синего",
  white: "белого",
  stone: "каменного",
  rock: "скального",
  shadow: "тени",
  deep: "глубокого",
  cold: "холодного",
  warm: "тёплого",
};

const MASCULINE_A_NOUNS = [
  "Вася", "Васька", "Васёк", "Илья", "Илюха", "Илюша", "Никита",
  "Даня", "Данила", "Миша", "Мишка", "Саша", "Сашка", "Паша", "Пашка",
  "Лёша", "Лёшка", "Серёга", "Серёжа", "Коля", "Колька", "Толя",
  "Витя", "Витька", "Генка", "Петька", "Федька", "Димка", "Вовка",
  "батя", "дядя", "дядька", "дядюшка", "дедушка", "папа", "мужчина",
  "парнишка", "мальчишка", "братишка", "старшина",
];

const PROPER_NAMES_RESTORE = [
  "Вася", "Васька", "Васьки", "Ваське", "Ваську", "Васькой",
  "Илья", "Ильи", "Илье", "Илью", "Ильёй", "Ильей",
  "Илюха", "Илюхи", "Илюхе", "Илюху", "Илюхой",
  "Лиза", "Лизы", "Лизе", "Лизу", "Лизой",
  "Гур", "Гура", "Гуру", "Гуром",
  "Паша", "Паши", "Пень", "Колода",
];

const ARTIFICIAL_TAIL_STUB_RE =
  /(?<=[.!?])\s+(?:Прикинул|Решил|Подумал|Осознал|Смекнул|Отметил|Запомнил|Понял|Выдохнул|Вздохнул)\.(?=\s*(?:\n|$))/gu;

function normalizeForSimilarity(paragraph: string): string {
  return paragraph
    .toLowerCase()
    .replace(/ё/g, "е")
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function tokenJaccardSimilarity(a: string, b: string): number {
  const normA = normalizeForSimilarity(a);
  const normB = normalizeForSimilarity(b);
  if (!normA || !normB) return 0;
  if (normA === normB) return 1;

  const setA = new Set(normA.split(" ").filter((w) => w.length > 2));
  const setB = new Set(normB.split(" ").filter((w) => w.length > 2));
  if (setA.size < 5 || setB.size < 5) return 0;

  let intersection = 0;
  for (const token of setA) {
    if (setB.has(token)) intersection++;
  }
  const union = setA.size + setB.size - intersection;
  return union === 0 ? 0 : intersection / union;
}

function deduplicateParagraphs(text: string): { text: string; removedCount: number } {
  const blocks = text.split("\n");
  const kept: string[] = [];
  let removedCount = 0;

  for (const block of blocks) {
    const trimmed = block.trim();
    if (!trimmed || trimmed.length < 45) {
      kept.push(block);
      continue;
    }

    let isDuplicate = false;
    const windowStart = Math.max(0, kept.length - 6);
    for (let i = windowStart; i < kept.length; i++) {
      const prev = kept[i].trim();
      if (prev.length < 45) continue;
      if (tokenJaccardSimilarity(prev, trimmed) >= 0.82) {
        isDuplicate = true;
        removedCount++;
        break;
      }
    }

    if (!isDuplicate) {
      kept.push(block);
    }
  }

  return { text: kept.join("\n"), removedCount };
}

export function sanitizeGeneratedText(rawText: string): TextHygieneResult {
  const punctuationNotes: string[] = [];
  let text = rawText ?? "";

  const hiddenMatches = text.match(
    /[\u200B-\u200D\uFEFF\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F-\u009F]/g
  );
  const removedHiddenCharacters = hiddenMatches ? hiddenMatches.length : 0;
  if (removedHiddenCharacters > 0) {
    text = text.replace(
      /[\u200B-\u200D\uFEFF\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F-\u009F]/g,
      ""
    );
  }

  const normalizedLineEndings = /\r/.test(text);
  if (normalizedLineEndings) {
    text = text.replace(/\r\n?/g, "\n");
  }

  const spaceMatches = text.match(/[\t\u00A0\u1680\u2000-\u200A\u202F\u205F\u3000]| {2,}/g);
  const normalizedSpaces = spaceMatches ? spaceMatches.length : 0;
  text = text
    .replace(/[\t\u00A0\u1680\u2000-\u200A\u202F\u205F\u3000]/g, " ")
    .replace(/ {2,}/g, " ")
    .replace(/ *\n */g, "\n")
    .replace(/\n{3,}/g, "\n\n");

  let fixedPunctuationArtifacts = 0;

  let fixedLatinLeaks = 0;
  text = text.replace(
    /([А-ЯЁа-яё]+)-([A-Za-z]+)|([A-Za-z]+)-([А-ЯЁа-яё]+)/g,
    (full, cyr1, lat1, lat2, cyr2) => {
      fixedLatinLeaks++;
      if (cyr1 && lat1) {
        const replacement = LATIN_LEAK_MAP[lat1.toLowerCase()];
        return replacement ? `${cyr1}-${replacement}` : cyr1;
      }
      if (lat2 && cyr2) {
        const replacement = LATIN_LEAK_MAP[lat2.toLowerCase()];
        return replacement ? `${replacement}-${cyr2}` : cyr2;
      }
      return full;
    }
  );
  if (fixedLatinLeaks > 0) {
    punctuationNotes.push(`Исправлены англоязычные склейки в словах (${fixedLatinLeaks})`);
  }

  let fixedProperNounCase = 0;
  for (const properName of PROPER_NAMES_RESTORE) {
    const lowerName = properName.toLowerCase();
    const re = new RegExp(`([;:])\\s+${lowerName}(?![а-яё])`, "gu");
    text = text.replace(re, () => {
      fixedProperNounCase++;
      fixedPunctuationArtifacts++;
      return `. ${properName}`;
    });
  }
  if (fixedProperNounCase > 0) {
    punctuationNotes.push(
      `Восстановлены заглавные буквы имён собственных после точки с запятой (${fixedProperNounCase})`
    );
  }

  text = text.replace(/;\s+([А-ЯЁ])/gu, (_m, cap) => {
    fixedPunctuationArtifacts++;
    return `. ${cap}`;
  });

  text = text.replace(/(^|\n|[—–-]\s*)А:\s+чего\?/gu, (_m, prefix) => {
    fixedPunctuationArtifacts++;
    return `${prefix}А? Чего?`;
  });
  text = text.replace(/(Чего\s+там\s+ещ[её]):\s+/giu, (_m, prefix) => {
    fixedPunctuationArtifacts++;
    return `${prefix} — `;
  });

  let removedBurstinessStubs = 0;
  text = text.replace(ARTIFICIAL_TAIL_STUB_RE, () => {
    removedBurstinessStubs++;
    fixedPunctuationArtifacts++;
    return "";
  });
  if (removedBurstinessStubs > 0) {
    punctuationNotes.push(
      `Удалены искусственные однословные отбивки ритма (${removedBurstinessStubs})`
    );
  }

  let fixedGenderAgreement = 0;
  const mascPattern = MASCULINE_A_NOUNS.join("|");
  const genderRe = new RegExp(
    `(?<![А-ЯЁа-яё])(${mascPattern})((?:\\s+(?:уже|снова|опять|вдруг|сразу|тихо|быстро|молча|нехотя|тоже|также|чуть|едва|просто|сам))?)\\s+([а-яё]{2,}л)а(сь)?(?![а-яё])`,
    "giu"
  );
  text = text.replace(genderRe, (_full, name, adv, verbStem, refl) => {
    fixedGenderAgreement++;
    fixedPunctuationArtifacts++;
    const fixedSuffix = refl ? "ся" : "";
    return `${name}${adv ?? ""} ${verbStem}${fixedSuffix}`;
  });
  if (fixedGenderAgreement > 0) {
    punctuationNotes.push(
      `Исправлено согласование мужского рода для имён на -а/-я (${fixedGenderAgreement})`
    );
  }

  text = text.replace(/(^|\n)[-\u2010-\u2013]\s+/g, (_m, start) => {
    fixedPunctuationArtifacts++;
    return `${start}— `;
  });
  text = text.replace(/\s+[-\u2010-\u2013]\s+([а-яё])/g, (_m, letter) => {
    fixedPunctuationArtifacts++;
    return ` — ${letter}`;
  });

  text = text
    .replace(/\s+([.,!?:;])/g, (_m, p) => {
      fixedPunctuationArtifacts++;
      return p;
    })
    .replace(/([.,!?])\1{2,}/g, (full, p) => {
      if (p === ".") return "...";
      fixedPunctuationArtifacts++;
      return p;
    })
    .replace(/([,.!?])([А-ЯЁа-яёA-Za-z])/g, (_m, p, ch) => {
      fixedPunctuationArtifacts++;
      return `${p} ${ch}`;
    });

  const dedup = deduplicateParagraphs(text);
  text = dedup.text;
  const removedDuplicateParagraphs = dedup.removedCount;
  if (removedDuplicateParagraphs > 0) {
    punctuationNotes.push(`Удалены дублирующиеся абзацы (${removedDuplicateParagraphs})`);
  }

  const beforeYo = text;
  text = restoreYo(text);
  let restoredYo = 0;
  if (text !== beforeYo) {
    for (let i = 0; i < text.length; i++) {
      if (text[i] !== beforeYo[i] && (text[i] === "ё" || text[i] === "Ё")) {
        restoredYo++;
      }
    }
  }

  const changed = text !== rawText;

  return {
    text: text.trim(),
    report: {
      removedHiddenCharacters,
      normalizedSpaces,
      normalizedLineEndings,
      fixedPunctuationArtifacts,
      punctuationNotes,
      restoredYo,
      fixedLatinLeaks,
      fixedProperNounCase,
      fixedGenderAgreement,
      removedBurstinessStubs,
      removedDuplicateParagraphs,
      changed,
    },
  };
}

export function punctuationHygieneNote(report: TextHygieneReport): string {
  const parts: string[] = [];
  if (report.removedHiddenCharacters > 0) {
    parts.push(`скрытых символов: ${report.removedHiddenCharacters}`);
  }
  if (report.fixedPunctuationArtifacts > 0) {
    parts.push(`пунктуационных правок: ${report.fixedPunctuationArtifacts}`);
  }
  if (report.fixedLatinLeaks > 0) {
    parts.push(`латинских склеек: ${report.fixedLatinLeaks}`);
  }
  if (report.fixedProperNounCase > 0) {
    parts.push(`регистр имён: ${report.fixedProperNounCase}`);
  }
  if (report.fixedGenderAgreement > 0) {
    parts.push(`род глаголов: ${report.fixedGenderAgreement}`);
  }
  if (report.removedDuplicateParagraphs > 0) {
    parts.push(`дублей абзацев: ${report.removedDuplicateParagraphs}`);
  }
  if (report.restoredYo > 0) {
    parts.push(`восстановлено «ё»: ${report.restoredYo}`);
  }
  if (report.punctuationNotes.length > 0) {
    parts.push(report.punctuationNotes.join("; "));
  }
  return parts.length > 0 ? `Гигиена текста: ${parts.join(", ")}.` : "Гигиена текста: без замечаний.";
}
